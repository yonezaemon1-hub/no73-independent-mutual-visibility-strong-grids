"""Independent finite checker: graph adjacency and BFS, no path lemma used."""
from collections import deque

def run():
    pairs=grids=0
    for w in range(3,23):
        for h in (w,w+3):
            q=max(4,(w+1)//2)
            labels=[]
            # Generate a two-row table from column color pairs and phase flags.
            for col in range(w):
                if q%2:
                    base=(2*col)%q; pair=(base,(base+1)%q); flip=col//q
                else:
                    k=q//2; base=2*(col%k); pair=(base,base+1); flip=int(k<=col<3*k)
                labels.append(pair[(col+flip)%2])
                labels.append(pair[1-(col+flip)%2])
            C=[labels[2*j+i%2] for i in range(h) for j in range(w)]
            V=h*w; adj=[[] for _ in range(V)]
            for a in range(V):
                i,j=divmod(a,w)
                for x in range(max(0,i-1),min(h,i+2)):
                    for y in range(max(0,j-1),min(w,j+2)):
                        b=x*w+y
                        if b!=a:
                            assert C[a]!=C[b],(h,w,a,b)
                            adj[a].append(b)
            for a in range(V):
                dist=[-1]*V; dist[a]=0; queue=deque([a])
                while queue:
                    b=queue.popleft()
                    for z in adj[b]:
                        if dist[z]<0:
                            dist[z]=dist[b]+1
                            if C[z]!=C[a]: queue.append(z)
                i,j=divmod(a,w)
                for b in range(a+1,V):
                    if C[b]==C[a]:
                        x,y=divmod(b,w); assert dist[b]==max(abs(i-x),abs(j-y)),(h,w,a,b)
                        pairs+=1
            grids+=1
    print(f'PASS INDEPENDENT_BFS grids={grids} pairs={pairs} r=3..22 t=r,r+3')
if __name__=='__main__': run()
