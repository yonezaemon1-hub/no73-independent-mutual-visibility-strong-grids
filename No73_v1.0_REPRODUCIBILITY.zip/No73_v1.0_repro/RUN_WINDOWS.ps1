$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    Write-Host '=== NO73 v1.0 FINITE REPRODUCTION ==='
    & python -B -I .\verify_public_manifest.py
    if ($LASTEXITCODE -ne 0) { throw 'Public manifest failed' }
    $expected = @(Get-Content -LiteralPath .\EXPECTED_RESULTS.txt)
    $scripts = @('verify_paths.py', 'verify_bfs.py')
    for ($i = 0; $i -lt $scripts.Count; $i++) {
        $result = @(& python -B -I $scripts[$i])
        if ($LASTEXITCODE -ne 0) { throw ('Checker failed: ' + $scripts[$i]) }
        $result | Write-Host
        if ($result.Count -ne 1 -or $result[0] -cne $expected[$i]) {
            throw ('Output mismatch: ' + $scripts[$i])
        }
    }
    Write-Host 'FINAL: PASS NO73_V1_FINITE_REPRODUCTION_ONLY'
} finally { Pop-Location }
