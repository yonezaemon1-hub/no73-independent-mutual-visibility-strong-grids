"""Finite verification of the explicit construction; not a proof of the infinite theorem."""
from itertools import combinations

def color(i,j,q):
    if q%2:
        return (2*j+((i+j+j//q)%2))%q
    k=q//2
    return 2*(j%k)+(i+j+int(k<=j<3*k))%2

def sign(x): return (x>0)-(x<0)

def witness(a,b,t,r,q):
    x,y=a; X,Y=b; s=color(x,y,q)
    h,d=abs(X-x),abs(Y-y)
    if d==0:
        z=y+1 if y+1<r else y-1
        return [a]+[(x+sign(X-x)*k,z) for k in range(1,h)]+[b]
    # Choose a source whose phase differs from every intervening support column.
    def good(a,b):
        i,j=a; l,m=b; p=(i+j)%2
        return all(color((p-k)%2,k,q)!=s for k in range(min(j,m)+1,max(j,m)))
    if not good(a,b):
        a,b=b,a
        assert good(a,b)
    x,y=a; X,Y=b; u,v=sign(X-x),sign(Y-y)
    if h>=d:
        return [(x+u*k,y+v*min(k,d-1)) for k in range(h)]+[b]
    out=[(x+u*min(k,h),y+v*k) for k in range(d+1)]
    for k in range(h+1,d):
        i,j=out[k]
        if color(i,j,q)==s:
            out[k]=(i+1 if i+1<t else i-1,j)
    return out

def run():
    count=0; grids=0
    for r in range(3,29):
        q=max(4,(r+1)//2)
        for t in (r,r+1,r+5):
            classes=[[] for _ in range(q)]
            for i in range(t):
                for j in range(r): classes[color(i,j,q)].append((i,j))
            for s,vs in enumerate(classes):
                for a,b in combinations(vs,2):
                    D=max(abs(a[0]-b[0]),abs(a[1]-b[1])); assert D>=2,(t,r,s,a,b)
                    p=witness(a,b,t,r,q)
                    assert len(p)==D+1 and {p[0],p[-1]}=={a,b},(t,r,a,b,p)
                    assert all(0<=i<t and 0<=j<r for i,j in p)
                    assert all(max(abs(i-k),abs(j-l))==1 for (i,j),(k,l) in zip(p,p[1:]))
                    assert all(color(i,j,q)!=s for i,j in p[1:-1]),(t,r,a,b,p)
                    count+=1
            grids+=1
    print(f'PASS PATH_WITNESSES grids={grids} pairs={count} r=3..28 t=r,r+1,r+5')
if __name__=='__main__': run()
