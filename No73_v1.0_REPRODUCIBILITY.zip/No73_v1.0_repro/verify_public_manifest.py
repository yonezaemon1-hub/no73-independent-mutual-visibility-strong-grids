"""Strict SHA-256 inventory for the separately constructed public package."""
from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = {
    'README.md', 'LICENSE.txt', 'RUN_WINDOWS.ps1',
    'verify_paths.py', 'verify_bfs.py', 'EXPECTED_RESULTS.txt',
    'verify_public_manifest.py', 'FROZEN_SOURCE_SHA256.txt',
    'frozen_original/verify_manifest.py',
}

def main():
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    if actual != EXPECTED | {'SHA256SUMS_PUBLIC.txt'}:
        raise SystemExit('FAIL PUBLIC INVENTORY')
    lines = (ROOT / 'SHA256SUMS_PUBLIC.txt').read_text(encoding='ascii').splitlines()
    names = set()
    for line in lines:
        digest, name = line.split('  ', 1)
        path = ROOT / name
        if name not in EXPECTED or name in names or not path.is_file() or path.is_symlink():
            raise SystemExit('FAIL PUBLIC MANIFEST ENTRY: ' + name)
        if sha256(path.read_bytes()).hexdigest() != digest:
            raise SystemExit('FAIL PUBLIC SHA256: ' + name)
        names.add(name)
    if names != EXPECTED:
        raise SystemExit('FAIL PUBLIC MANIFEST COVERAGE')
    print(f'PASS PUBLIC_SHA256_STRICT_INVENTORY files={len(names)}')

if __name__ == '__main__':
    main()
