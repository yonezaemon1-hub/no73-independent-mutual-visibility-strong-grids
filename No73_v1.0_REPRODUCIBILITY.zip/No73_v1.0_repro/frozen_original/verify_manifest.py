from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED={'MANUSCRIPT_v01.md','AUDIT_REQUEST.md','README.md','verify_paths.py','verify_bfs.py','verify_manifest.py','RUN_WINDOWS.ps1','EXPECTED_RESULTS.txt'}

def main():
    actual={p.name for p in ROOT.iterdir()}
    if actual != EXPECTED|{'SHA256SUMS.txt'}:
        raise SystemExit(f'FAIL INVENTORY extra={sorted(actual-EXPECTED-{"SHA256SUMS.txt"})} missing={sorted(EXPECTED-actual)}')
    seen=set()
    for line in (ROOT/'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
        h,n=line.split('  ',1)
        if n not in EXPECTED or n in seen or not (ROOT/n).is_file() or (ROOT/n).is_symlink(): raise SystemExit('FAIL MANIFEST ENTRY '+n)
        if sha256((ROOT/n).read_bytes()).hexdigest()!=h: raise SystemExit('FAIL SHA256 '+n)
        seen.add(n)
    if seen!=EXPECTED: raise SystemExit('FAIL MANIFEST COVERAGE')
    print(f'PASS SHA256_STRICT_INVENTORY files={len(seen)}')
if __name__=='__main__': main()
