# No.73 v1.0 finite reproducibility package

Requirements: Python 3.10 or newer, standard library. In the extracted
`No73_v1.0_repro` directory, run:

    python -B -I verify_public_manifest.py
    python -B -I verify_paths.py
    python -B -I verify_bfs.py

Expected results are in `EXPECTED_RESULTS.txt`. For Windows PowerShell 5.1,
run `powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN_WINDOWS.ps1`.
The wrapper verifies the public inventory and exact output; it changes only
the PowerShell process policy. No raw Windows logs are included.

`verify_paths.py`, `verify_bfs.py` and `EXPECTED_RESULTS.txt` are byte-identical
to the frozen v0.1 original. `frozen_original/verify_manifest.py` is also
byte-identical, retained solely to show the original strict private-bundle
inventory check; it expects files outside this public subset and MUST NOT be
used to check the public package. `verify_public_manifest.py` and
`SHA256SUMS_PUBLIC.txt` are the distinct public verifier and manifest.

The two finite checks test 573,778 and 145,194 same-color pairs in overlapping
domains, not a count of distinct pairs and not an infinite proof. An external
C++ source, its raw logs and private audit instructions are not included.

Human peer review and formal proof-assistant verification: NOT PERFORMED.
NOVELTY INCONCLUSIVE; REFERENCES PARTIAL.
Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
